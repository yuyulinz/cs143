Yulin Zhang ID:804483463, Email:leonzhang1996@gmail.com
Jonathan Cheung ID:504273334, Email:jcheung142@gmail.com

Project 2C, implemented everything in BTreeIndex.cc and finished insertAndSplit for BTNonLeafNode
SqlEngine.cc was not touched (yet)

Yulin Zhang ID:804483463, Email:leonzhang1996@gmail.com
Jonathan Cheung ID:504273334, Email:jcheung142@gmail.com

Project 2D, implemented everything.

CREATE TABLE Movie( 
       id int, 
       title varchar(100) NOT NULL, 
       year int, 
       rating varchar(10), 
       company varchar(50),
       CHECK (year < 2016),
       PRIMARY KEY(id))
       ENGINE = INNODB;
CREATE TABLE Actor( 
       id int, 
       last varchar(20), 
       first varchar(20), 
       sex varchar(6) NOT NULL, 
       dob date NOT NULL, 
       dod date,
       CHECK (sex='Female' OR sex='Male'),
       PRIMARY KEY(id))
       ENGINE = INNODB;
CREATE TABLE Director( 
       id int, 
       last varchar(20), 
       first varchar(20), 
       dob date, 
       dod date,
       CHECK (id > 0),
       PRIMARY KEY(id))
       ENGINE = INNODB;
CREATE TABLE MovieGenre( 
       mid int, 
       genre varchar(20),
       FOREIGN KEY (mid) REFERENCES Movie(id));
CREATE TABLE MovieDirector(
       mid int, 
       did int,
       FOREIGN KEY (mid) REFERENCES Movie(id),
       FOREIGN KEY (did) REFERENCES Director(id))
       ENGINE=INNODB;
CREATE TABLE MovieActor(
       mid int, 
       aid int, 
       role varchar(50),
       FOREIGN KEY (mid) REFERENCES Movie(id),
       FOREIGN KEY (aid) REFERENCES Actor(id))
       ENGINE=INNODB;
CREATE TABLE Review( 
       name varchar(20), 
       time timestamp, 
       mid int, 
       rating int, 
       comment varchar(500),
       FOREIGN KEY (mid) REFERENCES Movie(id))
       ENGINE=INNODB;
CREATE TABLE MaxPersonID( 
       id int);
CREATE TABLE MaxMovieID( 
       id int); 

/*PRIMARY KEY CONSTRAINTS

>EVERY MOVIE HAS ID
>EVERY ACTOR HAS ID
>EVERY DIRECTOR HAS ID

/*REFERENTIAL INTEGRITY CONSTRAINTS

>MOVIES IN MovieGenre SHOULD REFERENCE MOVIES IN Movie
>MOVIES IN MovieDirector SHOULD REFERENCE MOVIES IN Movie
>MOVIES IN MovieActor SHOULD REFERENCE MOVIES IN Movie
>ACTORS IN MovieActor SHOULD REFERENCE MOVIES IN Actor
>MOVIES IN Review SHOULD REFERENCE MOVIES IN Movie
>DIRECTOS IN MovieDirector SHOULD REFERENCE DIRECTORS IN Director

/*CHECK CONSTRAINTS

>YEAR IN Movies SHOULD NOT BE GREATER THAN 2016
>ID IN Movie SHOULD NOT BE NEGATIVE
>sex IN Actor SHOULD BE EITHER "Female" OR "Male"

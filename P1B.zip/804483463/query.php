<!DOCTYPE html>
<HTML lang="en">
	<head>
		<meta charset="utf-8">
		<title> CS143 Project 1B </title>
	</head>
	<body>
		<h1> SQL Queries </h1>
		<p> Type an SQL Query into the text area below. </p>
		<p> Example: SELECT * FROM Actor WHERE id=10; </p>
		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="GET">
			<textarea name="query" rows="9" cols="60"></textarea>
			<br>
			<input type="submit" value="submit"/>
		</form>

		<?php
		if ($_SERVER['REQUEST_METHOD'] == 'GET') {
			if (isset($_GET['query'])) {
				$db = new mysqli('localhost', 'cs143', '', 'CS143');
				if ($db->connect_errno > 0) {
					die('Unable to connect to database [' . $db->connect_error . ']');
				}

				//issue queries based on user input
				$query = $_GET['query'];
				$result = $db->query($query);
				if (!$result) {
					echo "<br> Query failed: $db->error";
					exit(1);
				}

				//parse the result from database and generate the result table
				$fieldcount = $result->field_count;
				echo "<br> <h2> Results: </h2>
						<table border='1' cellpadding='5'>
							<thead>
								<tr align='center'>";

				//get all of the fields names
				while ($field = $result->fetch_field()) {
					echo "<td> <b> $field->name </b> </td>";
				}
				echo "</tr> </thead> <tbody>";

				//get the value of each tuple and display it in the table
				while($row = $result->fetch_assoc()) {
					echo "<tr>";
					foreach ($row as $value) {
						if ($value != NULL)
							echo "<td> $value </td>";
						else
							echo "<td> N/A </td>";
					}
					echo "</tr>";
				}
				echo "</tbody> </table>";

				$result->free();
			}
		}?>
		<p> <small>Note: tables and fields are case sensitive. All tables in Project 1B are availale.</small> </p>
	</body>
</HTML>
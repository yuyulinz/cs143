/*
1) Get the movie id for the 'Die Another Day'. Cross product MovieActor and Actor to
get all information about which actor is in what movie, as well as their names.
2) Get only the valid entries of this cross product such that the ids of MovieActor and Actor are equal.
3) Grab all of the unqiue actor names from the resulting table.
 */
SELECT DISTINCT CONCAT(first, ' ', last)
FROM MovieActor m, Actor a
WHERE m.aid=a.id AND m.mid=(SELECT id
      		     		   FROM Movie
				   WHERE title='Die Another Day');

/*
1) Get all of the actors in the MovieActors table and group them together.
Count the number of movies each actor has been in. If it is greater than one,
then add it to the resulting table.
2) count the number of entries in the resulting table (x)
 */
SELECT count(*)
FROM (SELECT aid
	 FROM MovieActor
	 GROUP BY aid
	 HAVING count(*) > 1) x;


/* Find all the action movies with less than 20 actors */
SELECT mg.mid
FROM MovieGenre mg, MovieActor ma
WHERE mg.genre='Action' AND mg.mid=ma.mid
GROUP BY mg.mid 
HAVING count(*) < 2;

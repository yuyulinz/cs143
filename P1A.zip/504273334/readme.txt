I tried to match the demo calculator as closely as I could in my own project.

<?php
/*
Rules
1) no space between numbers, i.e. 2 0 is not 20
2) * and / is greater than + and -
3) space between operators is okay, i.e. 4 + 5, is okay with 4+5
4) letters and parentheses not allowed
*/

function validate_input () {
	if (isset($_GET['calc-input'])) {
		if (strlen($_GET['calc-input']) == 0)
			return false;
		
		$input = trim($_GET['calc-input']," ");
		$result;
		$invalid_characters = "#([^0-9\+\-*/. ]|^[\+*/]|[\+\-*/]$)#";
		$invalid_operators = "#([\+\*/][ ]*[\+*/]+|---+|-[\+*/]+|[\+*/][ ]+[-][ ]+)#";

		//check for only blanks as input
		if (strlen($input) == 0) {
			echo "Invalid Expression!";
			return false;
		}

		echo "<h2> Result </h2>";
		//check that only valid characters exist AND there is a valid number of operators, i.e. no ++
		if (!preg_match($invalid_characters, $input) && !preg_match($invalid_operators, $input)) {
				//parse the input and check that the operands are valid
				$result = preg_split("#(--|[\+\-*/])#", $input);
				foreach ($result as $value) {
					$value = trim($value, " ");
					//cannot have a " " between digits, start with a 0 if not a decimal
					//we will treat fractional numbers without a leading 0 as invalid, i.e. .123
					if (preg_match("#( |^0[0-9])|^[.]#", $value)) {
						echo "Invalid Expression!";
						return false;
					}
				}
				return true;
		} else {
				echo "Invalid Expression!";
				return false;
		}
	}
}

function evaluate_input ($expression) {
	 eval ('echo ' . $expression . ';');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title> PHP Calculator </title>
</head>
<body>
	<!-- HTML for calculator layout-->
	<h1> Calculator </h1>
	(Ver 1.0 by Jonathan Cheung)<br>
	Type an expression in the following box (e.g., 5+4*123).
	<p></p>

	<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="get" accept-charset="utf-8">
		<label for="calc-input"> Input: </label>
		<input name="calc-input" id="calc-input" type="text">
		<input id="submit-button" type="submit" value="Calculate">
	</form>

	<!-- info regarding valid inputs for this calculator-->
	<ul>
	    <li>Only numbers and +,-,* and / operators are allowed in the expression.
	    </li><li>The evaluation follows the standard operator precedence.
	    </li><li>The calculator does not support parentheses.
	    </li><li>The calculator handles invalid input "gracefully". It does not output PHP error messages.
	</li></ul>

	Here are some(but not limit to) reasonable test cases:
	<ol>
	  <li> A basic arithmetic operation:  3+4*5=23 </li>
	  <li> An expression with floating point or negative sign : -3.2+2*4-1/3 = 4.46666666667, 3*-2.1*2 = -12.6 </li>
	  <li> Some typos inside operation (e.g. alphabetic letter): Invalid input expression 2d4+1 </li>
	</ol>

	<!-- Result -->
	<?php
	if (validate_input()) {
		$expression = trim($_GET['calc-input']," ");
		$expression = str_replace("--", "- -", $expression);

		//check for dividing by 0
		if (preg_match("#/ *0#", $expression)) {
			echo "Division by zero error!";
			exit;
		}

		echo $expression . " = ";
		evaluate_input($expression);
	}
	?>
</body>
</html>

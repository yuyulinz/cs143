<?php include 'header.php' ?>
<div class="container">  
    <h1>Add new Movie</h1>
    
    <FORM ACTION="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" METHOD="GET">
    
      <!-- Title -->
      <b>Title:</b> <br>
      <INPUT TYPE="text" NAME="title"> <br> <br>

      <!-- Company -->
      <b>Company</b> <br>
      <INPUT TYPE="text" NAME="company"> <br> <br>

      <!-- Year -->
      <b>Year</b> <br>
      <INPUT TYPE="text" NAME="year"> <br> <br>

      <!-- MPAA Rating -->
      <b>MPAA Rating</b> <br>
      <SELECT NAME="rating">
      <OPTION SELECTED>G
      <OPTION>NC-17
      <OPTION>PG
      <OPTION>PG-13
      <OPTION>R
      <OPTION>surrendere
      </SELECT> <br> <br>

      <!-- Genre -->
      <b>Genre:</b>
      <INPUT TYPE="checkbox" NAME="action" Value="Action">Action
      <INPUT TYPE="checkbox" NAME="adult" Value="Adult">Adult
      <INPUT TYPE="checkbox" NAME="adventure" Value="Adventure">Adventure
      <INPUT TYPE="checkbox" NAME="animation" Value="Animation">Animation
      <INPUT TYPE="checkbox" NAME="comedy" Value="Comedy">Comedy
      <INPUT TYPE="checkbox" NAME="crime" Value="Crime">Crime
      <INPUT TYPE="checkbox" NAME="documentary" Value="Documentary">Documentary
      <INPUT TYPE="checkbox" NAME="drama" Value="Drama">Drama
      <INPUT TYPE="checkbox" NAME="family" Value="Family">Family
      <INPUT TYPE="checkbox" NAME="fantasy" Value="Fantasy">Fantasy
      <INPUT TYPE="checkbox" NAME="horror" Value="Horror">Horror
      <INPUT TYPE="checkbox" NAME="musical" Value="Musical">Musical
      <INPUT TYPE="checkbox" NAME="mystery" Value="Mystery">Mystery
      <INPUT TYPE="checkbox" NAME="romance" Value="Romance">Romance
      <INPUT TYPE="checkbox" NAME="sci-fi" Value="Sci-Fi">Sci-Fi
      <INPUT TYPE="checkbox" NAME="short" Value="Short">Short
      <INPUT TYPE="checkbox" NAME="thriller" Value="Thriller">Thriller
      <INPUT TYPE="checkbox" NAME="war" Value="War">War
      <INPUT TYPE="checkbox" NAME="western" Value="Western">Western
      <br> <br>

      <INPUT TYPE="submit" NAME="submit" VALUE="Add!">
    </FORM>

    <?php



      function checkFormat($title, $company, $year){
         

        /*** check length of title, company ***/
         
        $titlesize = strlen($title);
        $companysize = strlen($company);

        if ($titlesize == 0 || preg_replace("(\s+)","",$title) == "") {
            echo "ERROR: Title cannot be blank <br>";
            return 0;
        } else if ($titlesize > 100) {
            echo "ERROR: Title cannot be longer than 20 characters <br>";
            return 0;
        }

        if ($companysize == 0 || preg_replace("(\s+)","",$company) == "") {
            echo "ERROR: Company cannot be blank <br>";
            return 0;
        } else if ($companysize > 50) {
            echo "ERROR: Company cannot be longer than 50 characters <br>";
            return 0;
        }


	/*** check correct year input ***/

	if (!preg_match("/^[1-9][0-9][0-9][0-9]+$/", $year)) {
            echo "ERROR: $year is not correct value";
            return 0;
        }




        /*** passed all tests ***/
         
        return 1;
      }



      /*** adds genre given id, genre, and database ***/

      function addGenre($id, $genre, $db){

        $query = "INSERT INTO MovieGenre VALUES ("
                 . $id . ", \""
                 . $genre . "\");";

        $result = $db->query($query);

        if (!$result) {
            echo "ERROR: Failed to add genre to movie $db->error";
            exit(1);
        }
      }
      
      /*** end helper funtions, begin main code ***/

      if ($_SERVER['REQUEST_METHOD'] == 'GET') {
      
          /*** store all inputs ***/
         
          $title = $_GET['title'];
          $company = $_GET['company'];
          $year = $_GET['year'];
          $rating = $_GET['rating'];
          $action = $_GET['action'];
          $adult = $_GET['adult'];
          $adventure = $_GET['adventure'];
          $animation = $_GET['animation'];
          $comedy = $_GET['comedy'];
          $crime = $_GET['crime'];
          $documentary = $_GET['documentary'];
          $drama = $_GET['drama'];
          $family = $_GET['family'];
          $fantasy = $_GET['fantasy'];
          $horror = $_GET['horror'];
          $musical = $_GET['musical'];
          $mystery = $_GET['mystery'];
          $romance = $_GET['romance'];
          $scifi = $_GET['sci-fi'];
          $short = $_GET['short'];
          $thriller = $_GET['thriller'];
          $war = $_GET['war'];
          $western = $_GET['western'];
         
          
          if (isset($_GET['submit']) && checkFormat($title, $company, $year)) {

              
              /*** initiate database ***/
              
              $db = new mysqli('localhost', 'cs143', '', 'CS143');
              if ($db->connect_errno > 0) {
                  die('Unable to connect to database [' . $db->connect_error . ']');
              }


              /*** get current max ID ***/

              $result = $db->query("SELECT id FROM MaxMovieID");
              if (!result) {
                  echo "ERROR1: Failed to read MaxMovieID $db->error";
                  exit(1);
              }


              /*** add 1 to max ID and store as string ***/

              $row = $result->fetch_assoc();
              $newid = (int)$row['id'] + 1;
              $newid = strval($newid);
              

              


              /*** update MaxPersonID ***/
           
              $result = $db->query("UPDATE MaxMovieID SET id=$newid");
              if (!result) {
                  echo "ERROR: Failed to update MaxMovieID $db->error";
                  exit(1);
              }
         
            


              /*** create query string ***/
     
              $query = "INSERT INTO Movie VALUES ("
                       . $newid . ", \""
                       . $title . "\", "
                       . $year . ", \""
                       . $rating . "\", \""
                       . $company . "\");";
            


              /*** execute sql query ***/

              $result = $db->query($query);
              if (!result) {
                  echo "ERROR: FAILED to add Movie $db->error";
                  exit(1);
              } else {
                  if ($action != NULL) addGenre($newid, $action, $db);
                  if ($adult != NULL) addGenre($newid, $adult, $db);
                  if ($adventure != NULL) addGenre($newid, $adventure, $db);
                  if ($animation != NULL) addGenre($newid, $animation, $db);
                  if ($comedy != NULL) addGenre($newid, $comedy, $db);
                  if ($crime != NULL) addGenre($newid, $crime, $db);
                  if ($documentary != NULL) addGenre($newid, $documentary, $db);
                  if ($drama != NULL) addGenre($newid, $drama, $db);
                  if ($family != NULL) addGenre($newid, $family, $db);
                  if ($fantasy != NULL) addGenre($newid, $fantasy, $db);
                  if ($horror != NULL) addGenre($newid, $horror, $db);
                  if ($musical != NULL) addGenre($newid, $musical, $db);
                  if ($mystery != NULL) addGenre($newid, $mystery, $db);
                  if ($romance != NULL) addGenre($newid, $romance, $db);
                  if ($scifi != NULL) addGenre($newid, $scifi, $db);
                  if ($short != NULL) addGenre($newid, $short, $db);
                  if ($thriller != NULL) addGenre($newid, $thriller, $db);
                  if ($war != NULL) addGenre($newid, $war, $db);
                  if ($western != NULL) addGenre($newid, $western, $db);

                  echo "Add Success!"; 
              }
              $result->free();
          }
      }  
    ?>
  <div>	
  </body>
</html>

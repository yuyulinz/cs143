<?php include 'header.php' ?>
<div class="container">
    <h1>Add Movie/Actor Relation</h1>
    
    <FORM ACTION="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" METHOD="GET">
    
      <b>Movie Title:</b> <br>
      <SELECT NAME="movietitle">
      <OPTION>Select movie

      <?php 
	 $db = new mysqli('localhost', 'cs143', '', 'CS143');
	 if ($db->connect_errno > 0) {
             die('Unable to connect to database [' . $db->connect_error . ']');
         }

         $result = $db->query("SELECT id, title, year FROM Movie");
         if (!result) {
             echo "ERROR: Failed to get movies";
             exit(1);
         }

         while ($row = $result->fetch_assoc()) {
             $movietitle = $row['title'];
             $year = $row['year'];
             $id = $row['id'];
             echo "<OPTION VALUE=\"$id\">$movietitle ($year) <br>";
         }
         
      ?>

      </SELECT> <br> <br>
      

      <b>Actor:</b> <br>
      <SELECT NAME="actor">
      <OPTION>Select actor

      <?php
	 $result = $db->query("SELECT id, last, dob, first FROM Actor");
         if (!result) {
             echo "ERROR: Failed to get movies";
             exit(1);
         }

         while ($row = $result->fetch_assoc()) {
             $first = $row['first'];
             $last = $row['last'];
             $id = $row['id'];
             $dob = $row['dob'];
             echo "<OPTION VALUE=\"$id\">$first $last ($dob) <br>";
         }
      ?>

      </SELECT> <br> <br>
      

      <b>Role:</b> <br>
      <INPUT TYPE="text" NAME="role"> <br> <br>

      <INPUT TYPE="submit" NAME="submit" VALUE="Add me!">
    </FORM>

    <?php
       

       if ($_SERVER['REQUEST_METHOD'] == 'GET') {
          
           $actorid = $_GET['actor'];
           $movieid = $_GET['movietitle'];
           $role = $_GET['role'];
           

           if (isset($_GET['submit'])) {
               if ($movieid == "Select movie") {
                   echo "ERROR: Please select a movie.";
                   exit(1);
               }
               if ($actorid == "Select actor") {
                   echo "ERROR: Plese select an actor.";
                   exit(1);
               }
               if (strlen($role) == 0) {
                   echo "ERROR: Actor should have role.";
                   exit(1);
               }
               if (strlen($role) > 50) {
                   echo "ERROR: Role cannot be more than 50 chars long";
                   exit(1);
               }
                      

               $query = "INSERT INTO MovieActor VALUES ("
                        . $movieid . ", "
                        . $actorid . ", \""
                        . $role . "\");";
               $result = $db->query($query);
               if (!result) {
                   echo "ERROR: Failed to add Movie/Actor relation $db->error";
                   exit(1);
               }
               echo "Add Successful";
               $result->free();
           }
       }
    ?>
</div>
  </body>
</html>

<?php

//used to search for movies and actors based on the keyword
//used for browse.php for actor or movie search and search.php searching for keyterms relating to
//both movie and actors
function browse($title, $search_term) {
	$db = new mysqli('localhost', 'cs143', '', 'CS143');
	if ($db->connect_errno > 0) {
		die('Unable to connect to database [' . $db->connect_error . ']');
	}

	//Search Query for Actor Table
	//word search implemented by searching for term as a first name, then a last name
	//multi-word search uses AND
	if ($title == 'Actor') {
		$search = explode(" ", $search_term);
		if (count($search) > 1) {
			$query = "SELECT id, first, last, dob
					  FROM Actor
					  WHERE first LIKE '%$search[0]%' AND last LIKE '%$search[1]%'
					  ORDER BY last ASC;";

		} else {
			//empty search term
			if ($search[0] == "")
				$query =  "SELECT id, first, last, dob FROM Actor ORDER BY last ASC;";
			else
				$query = "SELECT id, first, last, dob
						  FROM Actor
						  WHERE first LIKE '%$search[0]%' OR last LIKE '%$search[0]%'
						  ORDER BY last ASC;";
		}
	}
	//Search Query for Movie Table
	 else {
	 	$search = $search_term;
	 	if (ctype_space($search) || $search == "")
	 		$query = "SELECT id, title, year FROM Movie ORDER BY title;";
	 	else {
	 		$query = "SELECT id, title, year 
	 				  FROM Movie 
	 				  WHERE title LIKE '%$search%' ORDER BY title;";
	 	}
	}
	$result = $db->query($query);
	queryHandler($db, $result);
	//parse the result from database and generate the result table
	echo "<h4> Results: </h4>
			<table class='table table-hover'>
				<thead>
					<tr>";

	//get all of the fields names
	while ($field = $result->fetch_field()) {
		if ($field->name != 'id')
			echo "<td> <b> " . strtoupper($field->name) . " <b> </td>";
	}
	echo "</tr> </thead> <tbody>";

	//get the value of each tuple and display it in the table
	while($row = $result->fetch_assoc()) {
		echo "<tr>";
		$r_id = $row['id'];
		foreach ($row as $key => $value) {
			if ($title == 'Actor')
				$showlink = 'show_actor.php';
			else
				$showlink = 'show_movie.php';
			if ($key != 'id')
				echo "<td> <a href='$showlink?id=$r_id'> $value </a> </td>";	
		}
		
		echo "</tr>";
	}
	echo "</tbody> </table>";

	$result->free();
}

//handle database errors
function queryHandler($db, $result) {
	if (!$result) {
		echo "<br> Query failed: $db->error.";
		exit(1);
	}
}

//create html table for query entries
function createInfoTable ($result, $type) {
	echo "<table class='table'>
		  	<thead>
		  		<tr>";
    
	while ($field = $result->fetch_field()) {
		if ($field->name != 'mid' && $field->name != 'aid')
			echo "<td> <b>". strtoupper($field->name) ."</b> </td>";
	}
	echo "</tr> </thead> <tbody>";
	
	$row = $result->fetch_assoc();
	do {
		if (!isset($row)) {
			echo " <tr> <td> N/A </td> <td> N/A </td> <td> N/A </td> </tr>";
			break;
		}
		echo "<tr>";
		if ($type == 'Actor')
			$id = $row['aid'];
		else
			$id = $row['mid'];
		foreach ($row as $key => $value) {
			if ($key == 'mid' || $key == 'aid')
				continue;
			if ($value == NULL && $type == 'Info')
				echo "<td> Still Alive </td>";
			elseif ($type == 'Movie' && $key == 'title')
				echo "<td> <a href='show_movie.php?id=$id'> $value </a> </td>";
			elseif ($type == 'Actor' && $key == 'name')
				echo "<td> <a href='show_actor.php?id=$id'> $value </a> </td>";				
			else
				echo "<td> $value </td>";
		}
		echo "</tr>";
	} while($row = $result->fetch_assoc());
	echo "</tbody> </table>";
}
?>
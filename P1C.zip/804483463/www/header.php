<!DOCTYPE html>
<html>
	<head lang="en">
		<title> CS143 Project 1C </title>
		<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
	  	<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
	  	<script type="text/javascript" src="jquery-3.1.1.min.js"></script>	  	
	  	<script type="text/javascript" src="bootstrap.min.js"></script>  	
	</head>
	<body>
		<div class="container-fluid">
		<nav class="navbar navbar-default navbar-static-top">
			<div class="container">
				<div class="navbar-header">
					<a class="navbar-brand" href="index.php"> CS 143 Project 1C </a>
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
						<span class="sr-only"> Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>							
					</button>
				</div>
				<div id="navbar" class="navbar-collapse collapse in" aria-expanded="true">
				          <ul class="nav navbar-nav">
							<li class="dropdown">
				              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
				               aria-haspopup="true" aria-expanded="false"> Add Content <span class="caret"></span></a>
				              <ul class="dropdown-menu">
				                <li><a href="addactdir.php">Add Actor/Director</a></li>
				                <li><a href="addmov.php">Add Movie Information</a></li>
				                <li role="separator" class="divider"></li>
				                <li class="dropdown-header">Relations</li>
				                <li><a href="addMAR.php">Add Movie/Actor Relation</a></li>
				                <li><a href="addMDR.php">Add Movie/Director Relation</a></li>
				              </ul>
							</li>
							<li class="dropdown">
				              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
				               aria-haspopup="true" aria-expanded="false"> Browse <span class="caret"></span></a>
				              <ul class="dropdown-menu">
				                <li><a href="browse.php?title=Actor"> Show Actor Information </a></li>
				                <li><a href="browse.php?title=Movie"> Show Movie Information </a></li>
				              </ul>
							</li>
							<li><a href="search.php"> Search </a></li>												            
				          </ul>
				</div>
			</div>
		</nav>
		</div>
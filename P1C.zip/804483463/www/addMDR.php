<?php include 'header.php' ?>
<div class="container">
    <h1>Add Movie/Director Relation</h1>
    
    <FORM ACTION="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" METHOD="GET">
    
      <b>Movie Title:</b> <br>
      <SELECT NAME="movietitle">
      <OPTION>Select movie

      <?php 
	 $db = new mysqli('localhost', 'cs143', '', 'CS143');
	 if ($db->connect_errno > 0) {
             die('Unable to connect to database [' . $db->connect_error . ']');
         }

         $result = $db->query("SELECT id, title, year FROM Movie");
         if (!result) {
             echo "ERROR: Failed to get movies";
             exit(1);
         }

         while ($row = $result->fetch_assoc()) {
             $movietitle = $row['title'];
             $year = $row['year'];
             $id = $row['id'];
             echo "<OPTION VALUE=\"$id\">$movietitle ($year) <br>";
         }
         
      ?>

      </SELECT> <br> <br>
      

      <b>Director:</b> <br>
      <SELECT NAME="director">
      <OPTION>Select director

      <?php
	 $result = $db->query("SELECT id, last, first, dob FROM Director");
         if (!result) {
             echo "ERROR: Failed to get director";
             exit(1);
         }

         while ($row = $result->fetch_assoc()) {
             $first = $row['first'];
             $last = $row['last'];
             $id = $row['id'];
             $dob = $row['dob'];
             echo "<OPTION VALUE=\"$id\">$first $last ($dob) <br>";
         }
      ?>

      </SELECT> <br> <br>

      <INPUT TYPE="submit" NAME="submit" VALUE="Add me!">
    </FORM>

    <?php
       

       if ($_SERVER['REQUEST_METHOD'] == 'GET') {
          
           $directorid = $_GET['director'];
           $movieid = $_GET['movietitle'];
           
           

           if (isset($_GET['submit'])) {
               if ($movieid == "Select movie") {
                   echo "ERROR: Please select a movie.";
                   exit(1);
               }
               if ($directorid == "Select director") {
                   echo "ERROR: Plese select a director.";
                   exit(1);
               }  

               $query = "INSERT INTO MovieDirector VALUES ("
                        . $movieid . ", "
                        . $directorid . ");";
               $result = $db->query($query);
               if (!result) {
                   echo "ERROR: Failed to add Movie/Diector relation $db->error";
                   exit(1);
               }
               echo "Add Successful $movieid $directorid";
               $result->free();
           }
       }
    ?>
</div>
  </body>
</html>

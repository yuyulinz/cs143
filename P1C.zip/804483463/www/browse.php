<?php
include 'header.php';
include 'utilities.php';
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
	if ($_GET['title'] == 'Movie')
		$title = 'Movie';
	else
		$title = 'Actor';
}		
?>
	
<div class="container">
	<h2> <?php echo $title ?> Information </h2>
	<hr>
	<form class="text-center" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="GET">
		<label style="display: block;"> Search: <input type="text" placeholder="<?php if ($title == 'Movie') echo "Dark Knight.."; else echo "Tom Hanks.."; ?>"
		name="query" style="width: 90%; margin-bottom: 5px"> </label>
		<input type="hidden" name="title" value="<?php echo $title;?>">
		<button type="submit" class="btn btn-primary"> Submit </button>
	</form>

	<?php
		if($_SERVER['REQUEST_METHOD'] == 'GET') {
			if (isset($_GET['query'])) {
				browse($title, $_GET['query']);				
			}
		}
	?>
</div>
</body>
</html>

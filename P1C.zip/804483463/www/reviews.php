<?php include 'header.php'; include 'utilities.php';
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
	if (isset($_GET['mid']))
		$mid = $_GET['mid'];
	if (isset($_GET['submitted'])) {
		$db = new mysqli('localhost', 'cs143', '', 'CS143');
		if ($db->connect_errno > 0) {
			die('Unable to connect to database [' . $db->connect_error . ']');
		}
		$name = $_GET['name'];
		$rating = $_GET['rating'];
		$comment = $_GET['comment'];
		$time =  date('Y-m-d H:i:s', strval(time()));
		$query = "INSERT INTO Review
				  VALUES ('$name', '$time', $mid, $rating, '$comment')";
		$result = $db->query($query);
		queryHandler($db, $result);
		echo "<div class='container'> Successfully Submitted Review! <br> <br>
				<a href='show_movie.php?id=$mid'> Return to Previous Page </a> <hr>
			</div>";
	}
}
?>

<div class="container">
	<h2> Add Review </h2>
	<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method='GET' style="width: 85%; margin: 0 auto;">
		<div class="form-group">
			<label for="name"> Name: </label>
			<input type="text" value="Anonymous" name="name" id="name" class="form-control">
		</div>
		<div class="form-group">
			<label for="rating"> Rating: </label>
			<select name="rating" id="rating" class="form-control">
				<option value='1'> 1 </option>
				<option value='2'> 2 </option>
				<option value='3'> 3 </option>
				<option value='4'> 4 </option>
				<option value='5'> 5 </option>				
			</select>
		</div>
		<div class="form-group">
			<label for="comment"> Comment: </label>
			<textarea  name="comment" id="comment" class="form-control" rows='6'> </textarea>
		</div>
		<input type="hidden" value="submitted" name="submitted">
		<div class="text-center">
			<button type="submit" class="btn btn-success"> Submit </button>
		</div>
		<input type="hidden" value="<?php echo $mid;?>" name="mid">
	</form>
</div>

</body>
</html>
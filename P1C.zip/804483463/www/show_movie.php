<?php include 'header.php'; include 'utilities.php';?>
<div class="container">
	<h2> Movie Information </h2>
	<hr>	
	<h4> General </h4>

<?php
//grab query string arguments and have SQL request
if($_SERVER['REQUEST_METHOD'] == 'GET') {
	if (isset($_GET['id'])) {
		$mid = $_GET['id'];
		$db = new mysqli('localhost', 'cs143', '', 'CS143');
		if ($db->connect_errno > 0) {
			die('Unable to connect to database [' . $db->connect_error . ']');
		}

		//create movie info list information
		//assume that the query only returns a single tuple
		//each movie can have more than one genre
		$query = "SELECT title, year, rating, company As Producer, CONCAT (last, ', ', first) As Director, genre
				  FROM Movie, MovieGenre, MovieDirector, Director
				  WHERE Movie.id=$mid AND MovieGenre.mid=$mid AND MovieDirector.mid=$mid AND Director.id=MovieDirector.did
				  GROUP BY genre
				  HAVING COUNT(*) > 0";
		$result = $db->query($query);
		//director information is not found
		if ($result->num_rows == 0) {
			$query = "SELECT title, year, rating, company As Producer, genre
					  FROM Movie, MovieGenre
					  WHERE Movie.id=$mid AND MovieGenre.mid=$mid
					  GROUP BY genre
					  HAVING COUNT(*) > 0";
			$result = $db->query($query);			
		}
		queryHandler($db, $result);
		//display all movie information besides drama
		echo "<ul class='list-group'>";
		$row = $result->fetch_assoc();
		foreach ($row as $key => $value) {
			if ($key == 'genre')
				$genre = $value;
			else 
				echo "<li class='list-group-item'> <h5 class='list-group-heading'>"
				. strtoupper($key) . ":</h5> $value </li>";			
		}

		//display genres
		echo "<li class='list-group-item'> <h5 class='list-group-heading'> GENRE: </h5> " . $genre;		
		while ($row = $result->fetch_assoc()) {
			echo ", $row[genre]";
		}
		
		echo " </li> </ul> <br> <h4> Actors </h4>";
		$result->free();

		//create actor info table
		$query = "SELECT CONCAT (first, ', ', last) As name, role, aid
				  FROM MovieActor, Actor
				  WHERE MovieActor.mid=$mid AND MovieActor.aid=Actor.id";
		$result = $db->query($query);
		queryHandler($db, $result);
		createInfoTable($result, 'Actor');
		$result->free();

	//User Reviews
	echo "<h4> Reviews </h4>";

	//get average rating
	$query = "SELECT AVG(rating) As score
			  FROM Review
			  WHERE mid=$mid";
	$result = $db->query($query);
	queryHandler($db, $result);
	$row = $result->fetch_assoc();
	$score = $row['score'];
	if ($score == "")
		$score = 'N/A';
	echo "<div> <b> Average Rating is </b> $score </div> <br>";
	$result->free();

	//get reviews
	$query = "SELECT name, time, rating, comment
			  FROM Review
			  WHERE mid=$mid";

	$result = $db->query($query);
	queryHandler($db, $result);

	echo "<ul class='list-group'>";
	//check to see if there is currently any reviews for this movie
	if ($result->num_rows == 0)
		echo "<li class='list-group-item text-center'> <p> Currently there are no reviews, be the first to add a review! </p>
			  <a class='btn btn-success' href='reviews.php?mid=$mid'> Add Review </a> </li>";
	else {
		while ($row = $result->fetch_assoc()) {
			echo "<li class='list-group-item'>";
			foreach ($row as $key => $value) {
				if ($key == 'name')
					echo "<div class='list-group-heading'> <b> $value </b>";
				elseif ($key == 'time')
					echo " ($value) </div>";
				elseif ($key == 'rating')
					echo "<b> Rating: </b> $value <br>";
				//key is Score
				elseif ($key == 'comment')
					echo "<b> Comment:</b> $value </li>";
			}
		}
		echo "<li class='list-group-item text-center'> <p> Add your own review! </p>
			  <a class='btn btn-success' href='reviews.php?mid=$mid'> Add Review </a> </li>";
	}
	echo "</ul>";

	}
}
?>
	<div style="background-color: #ddd; border-radius: 10px; padding: 10px; margin-bottom: 20px;">
		<h4> New Search </h4>
		<form class="text-center" action="search.php" method="GET">
			<input type="text" placeholder="Tom Hanks.."" name="query"
			style="width: 90%; display: block; margin-bottom: 10px">
			<button type="submit" class="btn btn-primary"> Submit </button>
		</form>
	</div>

</div>

</body>
</html>
<?php include 'header.php'; include 'utilities.php';?>

<div class="container">
	<h2> Search </h2>
	<hr>
	<form class="text-center" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="GET">
		<input type="text" placeholder="Tom Hanks.."
		name="query" style="width: 90%; display: block; margin-bottom: 10px">
		<button type="submit" class="btn btn-primary"> Submit </button>
	</form>
<?php
	if ($_SERVER['REQUEST_METHOD'] == 'GET') {
		$search_term = $_GET['query'];
		if (isset($search_term)) {
			echo "<h4 style='text-decoration: underline;'> ACTOR SEARCH: </h4>";
			browse('Actor', $search_term);
			echo "<h4 style='text-decoration: underline;'> MOVIE SEARCH: </h4>";			
			browse('Movie', $search_term);
		}
	}

?>
</div>

</body>
</html>
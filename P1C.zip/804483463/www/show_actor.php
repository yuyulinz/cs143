<?php include 'header.php'; include 'utilities.php';?>

<div class="container">
	<h2> Actor Information </h2>
	<hr>

<?php 
//grab query string arguments and have SQL request
if($_SERVER['REQUEST_METHOD'] == 'GET') {
	if (isset($_GET['id'])) {
		$aid = $_GET['id'];
		$db = new mysqli('localhost', 'cs143', '', 'CS143');
		if ($db->connect_errno > 0) {
			die('Unable to connect to database [' . $db->connect_error . ']');
		}

		//create actor info table
		$query = "SELECT CONCAT(first, ' ', last) As Name, sex, dob, dod 
				  FROM Actor
				  WHERE Actor.id=$aid;";			
		$result = $db->query($query);
		queryHandler($db, $result);
		createInfoTable($result, 'Info');
		$result->free();

		echo "<br> <h4> Movies </h4>";
		//get actor movie roles
		$query = "SELECT mid, role, title, year
				  FROM MovieActor, Movie
				  WHERE MovieActor.aid=$aid AND MovieActor.mid=Movie.id";
		$result = $db->query($query);
		queryHandler($db, $result);
		createInfoTable($result, 'Movie');
		$result->free();

	} else {
		echo "Error: could not find actor information!";
	}
}
?>
	<div style="background-color: #ddd; border-radius: 10px; padding: 10px; margin-bottom: 20px;">
		<h4> New Search </h4>
		<form class="text-center" action="search.php" method="GET">
			<input type="text" placeholder="Tom Hanks.."" name="query"
			style="width: 90%; display: block; margin-bottom: 10px">
			<button type="submit" class="btn btn-primary"> Submit </button>
		</form>
	</div>
</div>

</body>
</html>
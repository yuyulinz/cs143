<?php include 'header.php' ?>
<div class="jumbotron container">
	<h2> Home Page </h2>
	<hr>
	<p> Use the header to navigate the web interface!</p>
	<p> This was project was completed by Jonathan Cheung and Leon Zhang. </p>
</div>

</body>
</html>
<?php include 'header.php' ?>
  <div class="container">
    <h1>Add new Actor/Director</h1>
    
    <FORM action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="GET">
      
      <!-- Actor or Director -->
      <INPUT TYPE="radio" NAME="ActOrDir" VALUE="Actor" CHECKED> Actor
      <INPUT TYPE="radio" NAME="ActOrDir" VALUE="Director"> Director <br> <br>
      
      <!-- First name entry -->
      <b>First Name</b> <br>
      <INPUT TYPE="text" NAME="first"> <br> <br>
      
      <!-- Last name entry -->
      <b>Last Name</b> <br> 
      <INPUT TYPE="text" NAME="last"> <br> <br>
      
      <!-- Male or Female -->
      <INPUT TYPE="radio" NAME="Sex" VALUE="Male" CHECKED> Male
      <INPUT TYPE="radio" NAME="Sex" VALUE="Female"> Female <br> <br>
      
      <!-- Date of birth entry -->
      <b>Date of Birth</b> <br>
      <INPUT TYPE="text" NAME="dob"> <br>
      ie. 1997-05-05 <br> <br>
      
      <!-- Date of death entry -->
      <b>Date of Death</b> <br>
      <INPUT TYPE="text" NAME="dod"> <br> 
      leave blank if alive <br> <br>
      <INPUT TYPE="submit" NAME="submit" VALUE="add">
      
    </FORM>

    <?php

      function checkFormat($firstname, $lastname, $dob, $dod) {
        
        /*** check length of firstname, lastname, and dob ***/

        $firstsize = strlen($firstname);
        $lastsize = strlen($lastname);

        if ($firstsize == 0 || preg_replace("(\s+)","", $firstname) == "") {
            echo "ERROR: First name cannot be blank <br>";
            return 0;
        } else if ($firstsize > 20) {
            echo "ERROR: First name cannot be longer than 20 characters <br>";
            return 0; 
        }

        if ($lastsize == 0 || preg_replace("(\s+)","", $lastname) == "") {
            echo "ERROR: Last name cannot be blank <br>";
            return 0;
        } else if ($lastsize > 20) {
            echo "ERROR: Last name cannot be longer than 20 characters <br>";
            return 0;
        }

        if (strlen($dob) == 0) {
            echo "ERROR: Date of birth cannot be empty <br>";
            return 0;
        }



        /*** check correct date formatting ***/

        if (! preg_match("/^[1-2][0-9]{3}-(0[0-9]|1[0-2])-([0-2][0-9]|3[0-1])$/",$dob)) {
            echo "ERROR: Incorrect format for Date of birth <br>";
            return 0;
        }

        if ( strlen($dod) != 0 && !preg_match("/^[1-2][0-9]{3}-(0[0-9]|1[0-2])-([0-2][0-9]|3[0-1])$/", $dod)) {
            echo "ERROR: Incorrect format for Date of death <br>";
            return 0;
        }
        


        /*** passed all tests, return 1 ***/

        return 1;

      }


      if ($_SERVER['REQUEST_METHOD'] == 'GET') {
        
        /*** store all inputs ***/

        $ActOrDir = $_GET['ActOrDir'];  //store Actor or Director in ActOrDir
        $firstname = $_GET['first'];    //store first name in firstname
        $lastname = $_GET['last'];      //store last name in lastname
        $sex = $_GET['Sex'];            //store sex in sex
        $dob = $_GET['dob'];            //store date of birth
        $dod = $_GET['dod'];            //store date of death


        if( isset($_GET['submit']) && checkFormat($firstname, $lastname, $dob, $dod)) {

          /*** initiate database ***/

          $db = new mysqli('localhost', 'cs143', '', 'CS143');
          if ($db->connect_errno > 0) {
              die('Unable to connect to database [' . $db->connect_error . ']');
          }          



          /*** get current max ID ***/

          $result = $db->query("SELECT id FROM MaxPersonID");
          if (!$result) {
              echo "ERROR: Failed to read MaxPersonID $db->error";
              exit(1);
          }
          


          /*** add 1 to max ID and store as string ***/

          $row = $result->fetch_assoc();
          $newid = (int)$row['id'] + 1;
          $newid = strval($newid);


          
          /*** update MaxPersonID ***/

          $result = $db->query("UPDATE MaxPersonID SET id=$newid");
          if (!result) {
              echo "ERROR: Failed to update MaxPersonID $db->error";
              exit(1);
          }



          /*** set date of birth to null if empty ***/

          $dod_print;
          if ($dod == "") {
              $dod = "NULL";
              $dod_print = "Still alive";
          } else {
              $dod_print = $dod;
          }



          /*** create query string ***/


          if($ActOrDir == "Actor") {
              $query = "INSERT INTO " . $ActOrDir . " VALUES ("
                       . $newid . ", \""
                       . $lastname . "\", \""
                       . $firstname . "\", \""
                       . $sex . "\", \""
                       . $dob . "\", \""
                       . $dod . "\");";
          } else {
              $query = "INSERT INTO " . $ActOrDir . " VALUES ("
                       . $newid . ", \""
                       . $lastname . "\", \""
                       . $firstname . "\", \""
                       . $dob . "\", \""
                       . $dod . "\");";
	  }

          /*** execute sql query ***/

          $result = $db->query($query);
          if (!$result) {
              echo "ERROR: Failed to add Actor or Director $db->error";
              exit(1);
          } else {
              echo "Add Success: <br>" .  
                   $newid . " " .
                   $firstname . " " .
                   $lastname . " " .
                   $sex . " " .
                   $dob . " " .
                   $dod_print . "<br>";
          }
          $result->free();
        }
      }
    ?>
  </div>
  </body>
</html>

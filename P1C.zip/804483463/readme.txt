This project meets all of the criteria on the specs page.

The project was completed by Jonathan Cheung (504273334) and Yulin Zhang (804483463).

Jonathan Cheung handled the search pages, movie information, actor information, and reviews page. He also added a navigation header and an index page.

Yulin Zhang handled pages that add actors, directors, movies, movie/actor relations, and movie/director relations.



One aspect we can improve in our collaboration is our communication during the testing stage of our project. 
We both noticed similar bugs in the same pages and tried to fix them simultaneously in our own ways which created a conflict.
Next time we will check with each other before making changes to the project.